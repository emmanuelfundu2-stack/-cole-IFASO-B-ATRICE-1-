package com.gestion.scolaire

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "gestion_scolaire.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,className TEXT,phone TEXT,parentName TEXT)")
        db.execSQL("CREATE TABLE teachers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,subject TEXT,phone TEXT)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,studentName TEXT NOT NULL,amount REAL NOT NULL,date TEXT,note TEXT)")
        db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,studentName TEXT NOT NULL,date TEXT,status TEXT)")
        db.execSQL("CREATE TABLE grades(id INTEGER PRIMARY KEY AUTOINCREMENT,studentName TEXT NOT NULL,subject TEXT,grade REAL,coefficient REAL,term TEXT)")
        db.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,item TEXT NOT NULL,quantity INTEGER,alertAt INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE grades ADD COLUMN term TEXT DEFAULT 'Trimestre 1'")
    }
}
