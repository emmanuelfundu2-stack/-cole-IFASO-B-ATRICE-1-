package com.gestion.scolaire

import android.content.ContentValues
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var content: LinearLayout
    private lateinit var toolbar: com.google.android.material.appbar.MaterialToolbar
    private var logged = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = DatabaseHelper(this)
        toolbar = findViewById(R.id.toolbar); content = findViewById(R.id.content)
        logged = getPreferences(Context.MODE_PRIVATE).getBoolean("logged", false)
        if (!logged) login() else setupNavigation()
    }

    private fun login() {
        findViewById<BottomNavigationView>(R.id.navigation).visibility = android.view.View.GONE
        clear("Connexion administrateur")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(text("École C.S IFASO BÉATRICE 1", 25f))
        box.addView(text("Discipline – Travail – Réussite", 15f))
        val user = field("Nom d'utilisateur"); val pass = field("Mot de passe")
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(user); box.addView(pass)
        box.addView(button("Se connecter") {
            val savedUser = getPreferences(Context.MODE_PRIVATE).getString("user", "admin") ?: "admin"
            val savedPass = getPreferences(Context.MODE_PRIVATE).getString("pass", "admin123") ?: "admin123"
            if (user.text.toString().trim() == savedUser && pass.text.toString() == savedPass) {
                logged = true; getPreferences(Context.MODE_PRIVATE).edit().putBoolean("logged", true).apply(); setupNavigation()
            } else Toast.makeText(this, "Identifiants incorrects", Toast.LENGTH_SHORT).show()
        })
        box.addView(text("Première connexion : admin / admin123", 13f))
        content.addView(box)
    }

    private fun setupNavigation() {
        val nav = findViewById<BottomNavigationView>(R.id.navigation); nav.visibility = android.view.View.VISIBLE
        nav.menu.clear()
        listOf("Accueil","Élèves","Personnel","Finance","Notes").forEachIndexed { i, label ->
            nav.menu.add(0, i+1, i, label).setIcon(android.R.drawable.ic_menu_view)
        }
        nav.setOnItemSelectedListener { when(it.itemId) {1->dashboard();2->students();3->teachers();4->payments();5->grades()}; true }
        dashboard()
    }

    private fun clear(title: String) { toolbar.title = title; content.removeAllViews() }
    private fun text(v:String,s:Float=16f)=TextView(this).apply{text=v;textSize=s;setPadding(0,10,0,10)}
    private fun button(v:String,a:()->Unit)=Button(this).apply{text=v;setOnClickListener{a()}}
    private fun field(h:String)=EditText(this).apply{hint=h;setPadding(12,8,12,8)}
    private fun addRow(vararg views: android.view.View){views.forEach{content.addView(it)}}
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
    private fun query(sql:String)=db.readableDatabase.rawQuery(sql,null)
    private fun count(t:String)=query("SELECT COUNT(*) FROM $t").use{it.moveToFirst();it.getInt(0)}
    private fun money()=query("SELECT COALESCE(SUM(amount),0) FROM payments").use{it.moveToFirst();it.getDouble(0)}

    private fun dashboard(){
        clear("Tableau de bord")
        addRow(text("Bienvenue, Administrateur",22f),text("École C.S IFASO BÉATRICE 1",19f))
        addRow(text("👨‍🎓 Élèves : ${count("students")}"),text("👨‍🏫 Personnel : ${count("teachers")}"),text("💰 Total paiements : ${"%.2f".format(money())}"))
        addRow(button("➕ Nouvel élève"){students()},button("💳 Nouveau paiement"){payments()},button("📝 Saisir une note"){grades()},button("📅 Présences"){attendance()},button("📦 Inventaire"){inventory()},button("📄 Bulletin"){reportCard()},button("⚙️ Paramètres"){settings()})
        content.addView(text("Application hors connexion. Les données restent sur cet appareil.",13f))
    }

    private fun students(){
        clear("Élèves")
        val name=field("Nom complet *"); val cls=field("Classe"); val phone=field("Téléphone"); val parent=field("Parent / tuteur")
        addRow(name,cls,phone,parent,button("Ajouter l'élève"){ if(name.text.isBlank()){toast("Le nom est obligatoire");return@button}; val v=ContentValues().apply{put("name",name.text.toString());put("className",cls.text.toString());put("phone",phone.text.toString());put("parentName",parent.text.toString())};db.writableDatabase.insert("students",null,v);students() })
        content.addView(text("Liste des élèves (${count("students")})",20f))
        query("SELECT id,name,className,phone,parentName FROM students ORDER BY name").use{c->while(c.moveToNext()){val id=c.getInt(0);val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};row.addView(text("${c.getString(1)} — ${c.getString(2)}\nParent: ${c.getString(4)} | ${c.getString(3)}"));row.addView(button("Supprimer"){db.writableDatabase.delete("students","id=?",arrayOf(id.toString()));students()});content.addView(row)}}
    }

    private fun teachers(){
        clear("Personnel / Enseignants"); val n=field("Nom complet *");val s=field("Matière / fonction");val p=field("Téléphone");addRow(n,s,p,button("Ajouter"){if(n.text.isBlank())return@button;val v=ContentValues().apply{put("name",n.text.toString());put("subject",s.text.toString());put("phone",p.text.toString())};db.writableDatabase.insert("teachers",null,v);teachers()});query("SELECT id,name,subject,phone FROM teachers ORDER BY name").use{c->while(c.moveToNext()){val id=c.getInt(0);content.addView(text("• ${c.getString(1)} — ${c.getString(2)} — ${c.getString(3)}"));content.addView(button("Supprimer"){db.writableDatabase.delete("teachers","id=?",arrayOf(id.toString()));teachers()})}}
    }

    private fun payments(){
        clear("Paiements scolaires");val st=field("Nom de l'élève *");val am=field("Montant *");am.inputType=2 or 8192;val note=field("Motif / tranche");addRow(st,am,note,button("Enregistrer"){val a=am.text.toString().toDoubleOrNull();if(st.text.isBlank()||a==null||a<=0){toast("Vérifie le nom et le montant");return@button};val v=ContentValues().apply{put("studentName",st.text.toString());put("amount",a);put("date",today());put("note",note.text.toString())};db.writableDatabase.insert("payments",null,v);payments()});content.addView(text("Total : ${"%.2f".format(money())}",20f));query("SELECT studentName,amount,date,note FROM payments ORDER BY id DESC").use{c->while(c.moveToNext())content.addView(text("• ${c.getString(0)} — ${c.getDouble(1)} — ${c.getString(2)}\n${c.getString(3)}"))}
    }

    private fun attendance(){
        clear("Présences");val st=field("Nom de l'élève");val sp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Présent","Absent","Retard","Justifié"))};addRow(st,sp,button("Enregistrer"){if(st.text.isBlank())return@button;val v=ContentValues().apply{put("studentName",st.text.toString());put("date",today());put("status",sp.selectedItem.toString())};db.writableDatabase.insert("attendance",null,v);attendance()});query("SELECT studentName,date,status FROM attendance ORDER BY id DESC LIMIT 100").use{c->while(c.moveToNext())content.addView(text("• ${c.getString(0)} — ${c.getString(1)} — ${c.getString(2)}"))}
    }

    private fun grades(){
        clear("Notes");val st=field("Nom de l'élève");val sub=field("Matière");val gr=field("Note /20");gr.inputType=2 or 8192;val co=field("Coefficient");co.inputType=2 or 8192;val term=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Trimestre 1","Trimestre 2","Trimestre 3"))};addRow(st,sub,gr,co,term,button("Enregistrer"){val g=gr.text.toString().toDoubleOrNull();val k=co.text.toString().toDoubleOrNull()?:1.0;if(st.text.isBlank()||sub.text.isBlank()||g==null||g<0||g>20)return@button;val v=ContentValues().apply{put("studentName",st.text.toString());put("subject",sub.text.toString());put("grade",g);put("coefficient",k);put("term",term.selectedItem.toString())};db.writableDatabase.insert("grades",null,v);grades()});query("SELECT studentName,subject,grade,coefficient,term FROM grades ORDER BY id DESC").use{c->while(c.moveToNext())content.addView(text("• ${c.getString(0)} — ${c.getString(1)} : ${c.getDouble(2)}/20 (coef ${c.getDouble(3)}) — ${c.getString(4)}"))};content.addView(button("Voir un bulletin"){reportCard()})
    }

    private fun reportCard(){
        clear("Bulletin / Moyenne");val st=field("Nom de l'élève");addRow(st,button("Calculer"){val name=st.text.toString();if(name.isBlank())return@button;var total=0.0;var coef=0.0;query("SELECT grade,coefficient,subject FROM grades WHERE studentName=?").use{c->while(c.moveToNext()){total+=c.getDouble(0)*c.getDouble(1);coef+=c.getDouble(1)}};content.addView(text("Élève : $name",20f));content.addView(text(if(coef>0)"Moyenne pondérée : ${"%.2f".format(total/coef)}/20" else "Aucune note enregistrée",18f));query("SELECT subject,grade,coefficient,term FROM grades WHERE studentName=?").use{c->while(c.moveToNext())content.addView(text("• ${c.getString(0)} : ${c.getDouble(1)}/20 — coef ${c.getDouble(2)} — ${c.getString(3)}"))}})
    }

    private fun inventory(){
        clear("Inventaire");val item=field("Article");val q=field("Quantité");q.inputType=2;val a=field("Seuil d'alerte");a.inputType=2;addRow(item,q,a,button("Ajouter"){val qi=q.text.toString().toIntOrNull()?:0;val al=a.text.toString().toIntOrNull()?:0;if(item.text.isBlank())return@button;val v=ContentValues().apply{put("item",item.text.toString());put("quantity",qi);put("alertAt",al)};db.writableDatabase.insert("inventory",null,v);inventory()});query("SELECT item,quantity,alertAt FROM inventory ORDER BY item").use{c->while(c.moveToNext()){val warn=if(c.getInt(1)<=c.getInt(2))" ⚠ STOCK BAS" else "";content.addView(text("• ${c.getString(0)} : ${c.getInt(1)} (seuil ${c.getInt(2)})$warn"))}}
    }

    private fun settings(){
        clear("Paramètres");val u=field("Nom d'utilisateur");val p=field("Nouveau mot de passe");p.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;addRow(u,p,button("Enregistrer les identifiants"){if(u.text.isBlank()||p.text.isBlank()){toast("Champs obligatoires");return@button};getPreferences(Context.MODE_PRIVATE).edit().putString("user",u.text.toString()).putString("pass",p.text.toString()).apply();toast("Identifiants mis à jour")});addRow(button("Déconnexion"){getPreferences(Context.MODE_PRIVATE).edit().putBoolean("logged",false).apply();logged=false;login()});content.addView(text("Les données sont stockées localement sur ce téléphone.",14f))
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
