# École C.S IFASO BÉATRICE 1 – Gestion scolaire v3

Application Android native Kotlin, hors connexion.

## Fonctionnalités
- Connexion administrateur avec changement d'identifiants
- Élèves : ajout, liste, suppression
- Personnel/enseignants : ajout, liste, suppression
- Paiements scolaires et total encaissé
- Présences : présent, absent, retard, justifié
- Notes par matière, coefficient et trimestre
- Calcul de moyenne pondérée et aperçu du bulletin
- Inventaire avec seuil d'alerte
- Tableau de bord

## Première connexion
Utilisateur : `admin`
Mot de passe : `admin123`

## Build release
Générer un Android App Bundle (.aab) signé avec une clé de signature protégée. Pour Google Play, utiliser Play App Signing.
